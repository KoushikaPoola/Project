package com.capgemini.controller;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.model.ElectronicProduct;
import com.capgemini.repository.ElectronicRepository;
import com.capgemini.service.EleService;

@Controller
public class EleController {
	
	@Autowired
	ElectronicRepository eleRepo;
	
	@Autowired
	EleService eleService;
	
	ElectronicProduct ele;
	
	
	@RequestMapping("/")
	public String index()
	{
		System.out.println("index");
		return "index.jsp";
	}
	
	@PostMapping(value="/addProduct")
	@ResponseBody
	public String addProduct(ElectronicProduct ele)
	{			
		eleRepo.save(ele);
		return "added";
		
	}
	
	@DeleteMapping(value="/deleteProduct")
	@ResponseBody
	public String deleteProduct(@RequestParam int code) 
	{
		eleService.deleteProduct(code);
		return "Deleted";
	}
	
	@RequestMapping(value="/searchProduct",method=RequestMethod.GET)
	public ModelAndView searchProduct(@RequestParam int code) 
	{
		ModelAndView mv=new ModelAndView("SearchLib.jsp");	
		ElectronicProduct ele =eleService.findProduct(code);
		mv.addObject(ele);
		return mv;
	}
		
	
	@PutMapping(value="/updateProduct")  
	public ModelAndView updateProduct(@RequestParam int code,@RequestParam String pName,@RequestParam double pprice,@RequestParam LocalDate createDate) 
	{
		ModelAndView mv=new ModelAndView("update.jsp");
		ElectronicProduct ele=eleService.updateProductDetails(code,pName,pprice,createDate);
		mv.addObject(ele);
		return mv;
	}
	
}
