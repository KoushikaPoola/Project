package com.capgemini.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.model.ElectronicProduct;
import com.capgemini.repository.ElectronicRepository;

@Service
public class EleService {

	@Autowired
	ElectronicRepository eleRepo;

	public void deleteProduct(Integer code) {
		eleRepo.deleteById(code);
	}

	public ElectronicProduct findProduct(Integer code) {

		Optional<ElectronicProduct> optional = eleRepo.findById(code);
		ElectronicProduct ele = optional.get();
		return ele;

	}


	public ElectronicProduct updateProductDetails(int code, String Name, double price, LocalDate createDate) {
		// TODO Auto-generated method stub
		
		ElectronicProduct b =findProduct(code);
		
		
	    b.setName(Name);
		b.setCode(code);
		b.setPrice(price);
		b.setCreateDate(createDate);
		eleRepo.save(b);
		return b;
	}
}
